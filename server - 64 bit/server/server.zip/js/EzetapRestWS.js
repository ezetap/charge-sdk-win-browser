var express=require("express"),
	utils=require('./util'),
	config = utils.readConfig('./config/config.json'),
	ezecli=require("./ezecli");
	eze = ezecli.ezecli(),
	ezetapRestImpl=require('./EzetapRestImpl').EzetapRestImpl(eze),
	app=express(),
	fs = require('fs'),
	bodyParser = require('body-parser'),
	log=require('./logger'),
	logger = log.getLogger('ezeClient-appender');


	if(config.httpPort!=null && config.wsPort!=null){
		app.listen(config.httpPort,'localhost');
		logger.info('HTTP Server started listening at port '+config.httpPort);
		require("./WebSocket.js").start(eze,config.wsPort)
	}else{
		logger.info("Error in starting server");
		return;
	}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

var baseUrl="/ezetap/v1"
app.post(baseUrl+'/initialize',function(req,res){
	var ezetapConfig=req.body;
	ezetapRestImpl.initialize(ezetapConfig,function(data){
		sendResponse(res,data);	
	});
});

app.get(baseUrl+'/prepareDevice',function(req,res){
	ezetapRestImpl.prepareDeviceFn(function(data){
		sendResponse(res,data);
	});
});

app.get(baseUrl+'/close',function(req,res){
	ezetapRestImpl.close(function(data){
		sendResponse(res,data);
	});
});

app.post(baseUrl+'/cardTransaction',function(req,res){
	var reqBody=req.body;
	logger.info("JSON********* "+JSON.stringify(reqBody));
	ezetapRestImpl.payCard(reqBody.amount,reqBody.mode,reqBody.options,function(data){
		sendResponse(res,data);
	});
});

app.post(baseUrl+'/cashTransaction',function(req,res){
	var reqBody=req.body;
	ezetapRestImpl.payCash(reqBody.amount,reqBody.options,function(data){
		sendResponse(res,data);
	});
});

app.post(baseUrl+'/chequeTransaction',function(req,res){
	var reqBody=req.body;
	ezetapRestImpl.payCheque(reqBody.amount,reqBody.cheque,reqBody.options,function(data){
		sendResponse(res,data);
	});
});

app.get(baseUrl+'/voidTransaction/:id',function(req,res){
	ezetapRestImpl.voidTransaction(req.params.id,function(data){
		sendResponse(res,data);
	});
});

app.get(baseUrl+'/searchTransaction',function(req,res){
	ezetapRestImpl.searchTransaction(req.query.startDate,req.query.endDate,function(data){
		sendResponse(res,data);
	});
});

app.get(baseUrl+'/viewTransaction/:id',function(req,res){
	ezetapRestImpl.viewTransaction(req.params.id,function(data){
		sendResponse(res,data);
	});
});

app.get(baseUrl+'/abortCurrentTransaction',function(req,res){
	ezetapRestImpl.abortCurrentTransaction(function(data){
		sendResponse(res,data);
	});
});

app.post(baseUrl+'/sendReceipt',function(req,res){
	var startDate=req.body;
	ezetapRestImpl.sendReceipt(reqBody,function(data){
		sendResponse(res,data);
	});
})

app.post(baseUrl+'/takeCardPayment',function(req,res){
	var chargeObj=req.body;
	ezetapRestImpl.takeCardPayment(chargeObj,function(data){
		sendResponse(res,data);
	});
})

app.post(baseUrl+'/takeCashPayment',function(req,res){
	var chargeObj=req.body;
	ezetapRestImpl.takeCashPayment(chargeObj,function(data){
		sendResponse(res,data);
	});
})

app.post(baseUrl+'/walletTransaction',function(req,res){
	logger.info('Ezetap rst wS inside walletTxn')
	var walletObj=req.body;
	ezetapRestImpl.walletTransaction(walletObj,function(data){
		sendResponse(res,data);
	});
})

app.post(baseUrl+'/confirmWalletTransaction',function(req,res){
	logger.info('Ezetap rst wS inside confirmWalletTxn')
	var walletObj=req.body;
	ezetapRestImpl.confirmWalletTransaction(walletObj,function(data){
		sendResponse(res,data);
	});
})

app.post(baseUrl+'/remoteTransaction',function(req,res){
	//logger.info('Ezetap rst wS inside confirmWalletTxn')
	var remotePayObj=req.body;
	ezetapRestImpl.remoteTransaction(remotePayObj,function(data){
		sendResponse(res,data);
	});
})

app.post(baseUrl+'/updateCustomer',function(req,res){
	//logger.info('Ezetap rst wS inside confirmWalletTxn')
	var customerObj=req.body;
	ezetapRestImpl.updateCustomer(customerObj,function(data){
		sendResponse(res,data);
	});
})

app.post(baseUrl+'/searchCharges',function(req,res){
	//logger.info('Ezetap rst wS inside confirmWalletTxn')
	var searchChargeObj=req.body;
	ezetapRestImpl.searchCharges(searchChargeObj,function(data){
		sendResponse(res,data);
	});
})

app.get(baseUrl+'/viewCharge/:id',function(req,res){
	//logger.info('Ezetap rst wS inside confirmWalletTxn')
	//var customerObj=req.body;
	ezetapRestImpl.viewCharge(req.params.id,function(data){
		sendResponse(res,data);
	});
})

function sendResponse(res,data){
	try{
		res.status("200");
		res.json(data);
	}catch(e){
		logger.debug('Exception in Send Response '+ e);
	}
	
}

