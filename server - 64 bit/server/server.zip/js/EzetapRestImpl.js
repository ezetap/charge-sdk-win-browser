'use strict'
var fs = require('fs');
var isInitialized=false,
//fs=require('fs');
log=require('./logger'),
logger = log.getLogger('ezeClient-appender');

function EzetapRestImplTest(eze){
	
	var thi=this;
	thi.ezecliLocation="./ezecli/ezecli.exe";
	thi.initializationDone=false;
	var ezecliWrapper=require('./EzecliPromiseWrapper').EzecliWrapper(eze);
	thi.appKey="";
	thi.propertyFile="property.txt"
	thi.accountId="";
	thi.username="";
	thi.isPrepareDeviceDone=false;
	thi.prepareDevice="false";
	thi.chargeBaseUrl="";
	thi.accountId="";

	thi.initialize=function(ezetapConfig,fn){
		logger.info('inside initialize '+JSON.stringify(ezetapConfig));
		logger.info(JSON.stringify(ezetapRestImpl));
		var appMode=0;
		try{
			if(ezetapConfig!=null){
				thi.accountId=ezetapConfig.accountId;
				thi.username=ezetapConfig.username;
				thi.prepareDevice=ezetapConfig.prepareDevice;
				thi.accountId=ezetapConfig.accountId;
				thi.writeProperty(JSON.stringify(ezetapConfig));
			}			
			if(thi.initializationDone){
				fn(responseObj("SUCCESS",null,{"message":"Initialization Done"}));
					return;
			}
			eze.setdriver(thi.ezecliLocation);
			logger.info('Driver set ');
			eze.start();
			logger.info('Started the ezecli')
			if(ezetapConfig.appMode==="PROD"){
				thi.chargeBaseUrl="services.ezetap.com"
				thi.appKey=ezetapConfig.prodAppKey;
				appMode=1;
			}else{
				thi.chargeBaseUrl="services-demo.ezetap.com"
				thi.appKey=ezetapConfig.demoAppKey;
				appMode=0;
			}
			
			logger.info("Going to set server type");
			ezecliWrapper.setServerType(appMode)
			.then(function(){
				logger.info("Going to login");
				return ezecliWrapper.login(ezetapConfig.username,thi.appKey,1);
			})
			.then(function(){
				logger.info("login successfull "); 
				isInitialized=true;
				thi.initializationDone=true;
				if(thi.prepareDevice=='true'){
					logger.info("Going to prepare device");
					return ezecliWrapper.prepareDevice();
				}else{
					fn(responseObj("SUCCESS",null,{"message":"Initialization Done"}));
					return;
				}				
			})
			.then(function(){
				fn(responseObj("SUCCESS",null,{"message":"Initialization Done"}));
			})
			.catch(function(apio){
					try{
						if(isInitialized || thi.initializationDone){
							ezecliWrapper.logout()
							.then(function(){
								isInitialized=false;
								thi.initializationDone=false;
								return ezecliWrapper.stop()
							})
						}
						if(apio!=undefined){
							var error=eze.model.StatusInfo.decode(apio.outData);
							fn(responseObj("FAILURE",errorObj(error.code,error.message),null));							
						}else{
							fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Supports!!!"),null));
						}
					}catch(e){
						fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Supportss!!!"),null));
					}
				})
			
		}catch(e){
				logger.info(e);
				fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Supportss!!!"),null));
		}
	}
	
	thi.writeProperty=function(ezetapConfig){
		logger.info("Enterring ");
		fs.writeFileSync(thi.propertyFile, ezetapConfig, {encoding: 'utf8'});
	}
	
	thi.prepareDeviceFn=function(fn){
		logger.info('Entering EzetapRestImpl prepareDevice')
		try{
			if(eze.User.isAuthenticated){
				ezecliWrapper.prepareDevice()
				.then(function(){
					thi.isPrepareDeviceDone=true;
					//thi.prepareDevice="true";
					fn(responseObj("SUCCESS",null,{"message":"Prepare Device Done"}));
				})
				.catch(function(apio){
					try{
						if(apio!=undefined){
							var error=eze.model.StatusInfo.decode(apio.outData);
							fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
						}else{
							fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
						}									
					}catch(e){
						fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
					}

				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			logger.info(e);
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
		
		
	}

	thi.abortCurrentTransaction=function(fn){
		logger.info('Entering EzetapRestImpl abortCurrentTransaction')
		try{
			if(eze.User.isAuthenticated){
				ezecliWrapper.abortCurrentTransaction()
				.then(function(){
					fn(responseObj("SUCCESS",null,{"message":"Operation Aborted"}));
				})
				.catch(function(apio){
					console.log('in catch clause')
					try{
						if(apio!=undefined){
							var error=eze.model.StatusInfo.decode(apio.outData);
							fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
						}else{
							fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
						}									
					}catch(e){
						fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
					}

				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			logger.info(e);
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
		
		
	}

	thi.logout=function(fn){
		try{
			if(eze.User.isAuthenticated){
				ezecliWrapper.logout()
				.then(function(){
					isInitialized=false;
					thi.initializationDone=false;
					return ezecliWrapper.stop();
				})
				.then(function(){
					fn(responseObj("SUCCESS",null,{"message":"Ezecli Closed"}));
				})
				.catch(function(apio){
					try{
						if(apio!=undefined){
							var error=eze.model.StatusInfo.decode(apio.outData);
							fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
						}else{
							fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
						}

					}catch(e){
						fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
					}
				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			logger.info(e);
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
		
	}

	thi.payCard=function(amount,mode,options,fn){
		try{
			logger.info('Entering payCard method'+amount+' mode='+mode);
			if(!thi.initializationDone){
				logger.info('Going to initialize in payCard')
				var data=fs.readFileSync(thi.propertyFile, 'utf8');
				var ezetapConfig=JSON.parse(data);
				//ezetapConfig.prepareDevice=true;
				ezecliWrapper.initialize(ezetapConfig)
				.then(function(){
					if(thi.prepareDevice==false){
						thi.prepareDeviceFn(function(prepareDeviceResponseData){
						
						if("SUCCESS"==prepareDeviceResponseData.status){
							thi.payCard(amount,mode,options,fn);
							//fn(prepareDeviceResponseData);
						}else{
							fn(prepareDeviceResponseData);
							//return;
						}
					})
					return;
					}
				})
				.catch(function(e){
					fn(responseObj("FAILURE",errorObj("EZECLI_0005","Exception in initializing again!!!"),null));
				})
				return;
			}	
			if(thi.initializationDone && !thi.isPrepareDeviceDone){
				logger.info('going to do prepare device in payCard');
				
					thi.prepareDeviceFn(function(prepareDeviceResponseData){
						
						if("SUCCESS"==prepareDeviceResponseData.status){
							thi.payCard(amount,mode,options,fn);
							//fn(prepareDeviceResponseData);
						}else{
							fn(prepareDeviceResponseData);
							return;
						}
					})
				return;

			}

			logger.info('Going to take payment');
			var additionalParams=populateAdditionalParams(options);
			if(eze.User.isAuthenticated){
				if( (!isValid(amount) || isNaN(amount)) && (!isValid(additionalParams.amountCashback) || isNaN(additionalParams.amountCashback)) ){
					return fn(responseObj("FAILURE",errorObj("EZECLI_0007","Invalid Amount or CashBack Amount"),null));
				}
				if("SALE"===mode){
					additionalParams.amountOther=0;
					ezecliWrapper.payCard(parseFloat(amount),additionalParams)
					.then(function(apio){
						var res=eze.model.Txn.decode(apio.outData);
						var serverResponse=JSON.parse(res.serverResponse);
						var txnId=serverResponse['txnId'];
						ezecliWrapper.addPayment(options.references.primaryRef,amount,'ezetap',txnId)
						.then(function(response){
							fn(responseObj("SUCCESS",null,constructPayementObj(serverResponse,"card",response.result)));
						})						
					})
					.catch(function(apio){
						var error=eze.model.StatusInfo.decode(apio.outData);
						fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
					})
				}else if("CASH@POS"===mode){
					ezecliWrapper.payCardCash(0,additionalParams.amountCashback,additionalParams)
					.then(function(apio){
						var res=eze.model.Txn.decode(apio.outData);
						fn(responseObj("SUCCESS",null,constructPayementObj(JSON.parse(res.serverResponse),"card")));
					})
					.catch(function(apio){
						var error=eze.model.StatusInfo.decode(apio.outData);
						fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
					})
				}else if("CASHBACK"===mode){
					ezecliWrapper.payCardCash(parseFloat(amount),additionalParams.amountCashback,additionalParams)
					.then(function(apio){
						var res=eze.model.Txn.decode(apio.outData);
						fn(responseObj("SUCCESS",null,constructPayementObj(JSON.parse(res.serverResponse),"card")));
					})
					.catch(function(apio){
						var error=eze.model.StatusInfo.decode(apio.outData);
						fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
					})
				}else{
					fn(responseObj("FAILURE",errorObj("EZECLI_0005","Mode Not Found"),null));
				}

			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			logger.info(e)
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Supportss!!!"),null));
		}
		
		
	}

	thi.payCash=function(amount,options,fn,charge){
		try{
			if(!thi.initializationDone){
				var data=fs.readFileSync(thi.propertyFile, 'utf8');
				var ezetapConfig=JSON.parse(data);
				//ezetapConfig.prepareDeviceRequired=false;
				ezecliWrapper.initialize(ezetapConfig)
				.then(function(){
					thi.payCash(amount,options,fn);
					
				})
				.catch(function(e){
					fn(responseObj("FAILURE",errorObj("EZECLI_0005","Exception in initializing again!!!"),null));
				})
				return;
			}
			logger.info('Going to take cash payment')
			var additionalParams=populateAdditionalParams(options);
			if(eze.User.isAuthenticated){
				ezecliWrapper.payCash(parseFloat(amount),additionalParams)
				.then(function(apio){
					var res=eze.model.Txn.decode(apio.outData);
					
						var serverResponse=JSON.parse(res.serverResponse);
						var txnId=serverResponse['txnId'];
						ezecliWrapper.addPayment(options.references.primaryRef,amount,'ezetap',txnId)
						.then(function(response){
							logger.info(response);
							fn(responseObj("SUCCESS",null,constructPayementObj(serverResponse,"cash",response.result)));
						})
					
				})
				.catch(function(apio){
					var error=eze.model.StatusInfo.decode(apio.outData);
					fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			logger.info(e);
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
		
	}

	thi.payCheque=function(amount,cheque,options,fn,charge){
		try{
			if(!thi.initializationDone){
				var data=fs.readFileSync(thi.propertyFile, 'utf8');
				var ezetapConfig=JSON.parse(data);
				ezetapConfig.prepareDeviceRequired=false;
				ezecliWrapper.initialize(ezetapConfig)
				.then(function(){
					thi.payCheque(amount,cheque,options,fn);
					
				})
				.catch(function(e){
					fn(responseObj("FAILURE",errorObj("EZECLI_0005","Exception in initializing again!!!"),null));
				})
				return;
			}
			var additionalParams=populateAdditionalParams(options);
			additionalParams.chequeNumber=cheque.chequeNumber
			additionalParams.bankCode=cheque.bankCode
			additionalParams.chequeDate=cheque.chequeDate
			if(eze.User.isAuthenticated){
				if(!isValid(additionalParams.chequeNumber) || !isValid(additionalParams.bankCode) || !isValid(additionalParams.chequeDate)){
					return fn(responseObj("FAILURE",errorObj("EZECLI_0008","Mandatory Parameters missing"),null));
				}
				

				ezecliWrapper.payCheque(parseFloat(amount),additionalParams)
				.then(function(apio){
					var res=eze.model.Txn.decode(apio.outData);
					fn(responseObj("SUCCESS",null,constructPayementObj(JSON.parse(res.serverResponse),"cheque")));
				})
				.catch(function(apio){
					var error=eze.model.StatusInfo.decode(apio.outData);
					fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			logger.info(e);
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
		
	}

	thi.voidTransaction=function(txnId,fn){
		try{
			if(eze.User.isAuthenticated){ 
				ezecliWrapper.voidTransaction(txnId)
				.then(function(apio){
					fn(responseObj("SUCCESS",null,{"message":"Transaction voided"}));
				})
				.catch(function(apio){
					var error=eze.model.StatusInfo.decode(apio.outData);
					fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
			
		}catch(e){
			logger.info(e);
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
		
	}

	thi.sendReceipt=function(data,fn){
		try{
			if(eze.User.isAuthenticated){
				ezecliWrapper.sendReceipt(data.txnId,data.customer.mobileNo,data.customer.email)
				.then(function(apio){
					fn(responseObj("SUCCESS",null,{"message":"Send e-receipt successful"}));
				})
				.catch(function(apio){
					var error=eze.model.StatusInfo.decode(apio.outData);
					fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
		
	}

	thi.viewTransaction=function(txnId,fn){
		try{
			if(eze.User.isAuthenticated){
				ezecliWrapper.getTransaction(txnId)
				.then(function(apio){
					var res=eze.model.Txn.decode(apio.outData);
					var response=JSON.parse(res.serverResponse);
					fn(responseObj("SUCCESS",null,constructPayementObj(response,response.paymentMode.toLowerCase())));
				})
				.catch(function(apio){
					var error=eze.model.StatusInfo.decode(apio.outData);
					fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
	}

	thi.searchTransaction=function(startDate,endDate,fn){
		try{
			if(eze.User.isAuthenticated){
				ezecliWrapper.searchTransaction(startDate,endDate)
				.then(function(apio){
					var res=eze.model.TxnHistory.decode(apio.outData);
					var data=constructTransactionObjectList(res);
					fn(responseObj("SUCCESS",null,data));
				})
				.catch(function(apio){
					try{
						var error=eze.model.StatusInfo.decode(apio.outData);
						fn(responseObj("FAILURE",errorObj(error.code,error.message),null));
					}catch(e){
						fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
					}
					
				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_0003","User Not Logged In. Log In and Try again!!!"),null));
			}
		}catch(e){
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
		}
	}

	thi.takeCardPayment=function(charge,fn){
		try{
			var amount=charge.amount;
			if(thi.initializationDone){
				if(!thi.isPrepareDeviceDone){
					thi.prepareDeviceFn(function(response){
						logger.info(response)
						if("SUCCESS"==response.status){
							thi.takeCardPayment(charge,fn);
							return;
						}else{
							if(response!=null){
								fn(response);
							}else
								fn(responseObj("FAILURE",errorObj("EZECLI_323024","Error occured during Initialize device."),null));
						}
					})
					
					return;
				}
				
				ezecliWrapper.createCharge(charge)
				.then(function(chargeResponse){
					//logger.info(chargeResponse)
					if("SUCCESS"==chargeResponse.status){
							var options={}
							options.references={}
							options.references.primaryRef=chargeResponse.result.id;
							options.references.ref2=thi.accountId;
							options.references.ref3="CHARGE";
							
							if(charge.customer!=null){
								options.customer={};
								options.customer.mobileNo=charge.customer.mobileNo;
								options.customer.emailId=charge.customer.emailId;
							}
							thi.payCard(amount,"SALE",options,fn);
					}else{
						fn(chargeResponse);
						return;
					}
					
					
				})
				.catch(function(){
					fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured in cardPayment. Contact Ezetap Support!!!"),null));
				})
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_323020","Device not initialized, call INITIALIZE API."),null))
			}						
		}catch(e){
			logger.info(e);
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured in cardPayment. Contact Ezetap Support!!!"),null));
		}
		
	}

	thi.takeCashPayment=function(charge,fn){
		//logger.info('inside take cash')
		logger.info("Enterring takeCashPayment")
		try{
			if(thi.initializationDone){
				var amount=charge.amount;
				ezecliWrapper.createCharge(charge)
				.then(function(chargeResponse){
					if("SUCCESS"==chargeResponse.status){
							var options={}
							options.references={}
							options.references.primaryRef=chargeResponse.result.id;
							options.references.ref2=thi.accountId;
							options.references.ref3="CHARGE";
							
							if(charge.customer!=null){
								options.customer={};
								options.customer.mobileNo=charge.customer.mobileNo;
								options.customer.emailId=charge.customer.emailId;
							}
							logger.info('Going to take cash payment');
							thi.payCash(amount,options,fn);
					}else{
						fn(response);
						return;
					}
					
					
				})
				.catch(function(){
					fn(responseObj("FAILURE",errorObj("","Exception"),null));
				})	
			}else{
				fn(responseObj("FAILURE",errorObj("EZECLI_323020","Device not initialized, call INITIALIZE API."),null))
			}		
		}catch(e){
			logger.info(e);
			fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Supportsss!!!"),null));
		}
	}

	thi.close=function(fn){
		if(thi.initializationDone){
			ezecliWrapper.logout()
			.then(function(){
					isInitialized=false;
					thi.initializationDone=false;
					return ezecliWrapper.stop()
				})
			.then(function(){
				fn(responseObj("SUCCESS",null,{"message":"Closed Successfully"}));
				return;
			})
			.catch(function(){
				fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
			})
		}else{
			fn(responseObj("SUCCESS",null,{"message":"Closed Successfully"}));
		}
	}

	thi.walletTransaction=function(walletObj,fn){
		logger.info('Ezetap rst wSimpl inside walletTxn '+JSON.stringify(walletObj));
		if(thi.initializationDone){
			var chargeId='';
			ezecliWrapper.createCharge(walletObj.charge)
			.then(function(chargeResponse){
				//logger.info(chargeResponse)
				if("SUCCESS"==chargeResponse.status){
					chargeId=chargeResponse.result.id;
					return ezecliWrapper.createWalletTransaction(chargeResponse.result.id,walletObj.walletProvider);
				}else if("FAILURE"==chargeResponse.status){
					fn(chargeResponse);
				}else{
					fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
				}
			})
			.then(function(walletResponse){
				var obj={};
				obj.status=walletResponse.status;
				console.log(walletResponse)
				if("SUCCESS"==walletResponse.status){
						obj.result={};
						obj.result.currentTxnId=walletResponse.result.txnId;
						obj.result.chargeId=chargeId;
				}else{
						obj.error={};
						obj.error=chargeResponse.error;	
				}
				fn(obj);
			})
			.catch(function(){
				fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
			})
		}else{
			fn(responseObj("FAILURE",errorObj("EZECLI_323020","Device not initialized, call INITIALIZE API."),null))
		}
	}

	thi.confirmWalletTransaction=function(walletObj,fn){
		logger.info('Ezetap rest wSimpl inside confirmWalletTransaction ');
		if(thi.initializationDone){
				
			ezecliWrapper.confirmWalletTransaction(walletObj.txnId,walletObj.walletOTP)
			.then(function(walletResponse){
				//logger.info//(walletResponse)
				if("SUCCESS"==walletResponse.status){
					return fn(walletResponse);
				}else if("FAILURE"==chargeResponse.status){
					fn(walletResponse);
				}else{
					fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
				}
			})
			.catch(function(){
				fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
			})
		}else{
			fn(responseObj("FAILURE",errorObj("EZECLI_323020","Device not initialized, call INITIALIZE API."),null))
		}
	}

	thi.remoteTransaction=function(remoteObj,fn){
		logger.info('Ezetap rst wSimpl inside remoteTransaction '+JSON.stringify(remoteObj));
		if(thi.initializationDone){
			var chargeId='';
			ezecliWrapper.createCharge(remoteObj.charge)
			.then(function(chargeResponse){
				//logger.info(chargeResponse)
				if("SUCCESS"==chargeResponse.status){
					chargeId=chargeResponse.result.id;
					return ezecliWrapper.remoteTransaction(chargeResponse.result.id);
				}else if("FAILURE"==chargeResponse.status){
					fn(chargeResponse);
				}else{
					fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
				}
			})
			.then(function(remotePayResponse){
				var obj={};
				obj.status=remotePayResponse.status;
				//console.log(walletResponse)
				if("SUCCESS"==remotePayResponse.status){
						obj.result={};
						obj.result.chargeId=chargeId;
				}else{
						obj.error={};
						obj.error=remotePayResponse.error;	
				}
				fn(obj);
				//fn(remotePayResponse);
			})
			.catch(function(){
				fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
			})
		}else{
			fn(responseObj("FAILURE",errorObj("EZECLI_323020","Device not initialized, call INITIALIZE API."),null))
		}
	}

	thi.updateCustomer=function(customerObj,fn){
		if(thi.initializationDone){
			
			ezecliWrapper.updateCustomer(customerObj)
			.then(function(response){
				//logger.info(response)
				fn(response);
			})
			.catch(function(){
				fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
			})
		}else{
			fn(responseObj("FAILURE",errorObj("EZECLI_323020","Device not initialized, call INITIALIZE API."),null))
		}
	}

	thi.viewCharge=function(chargeId,fn){
		if(thi.initializationDone){
				
			ezecliWrapper.viewCharge(chargeId)
			.then(function(response){
				//logger.info(response)
				var obj={};
				obj.status=response.status;
				obj.error={};
				obj.error=response.error;
				obj.result={};
				obj.result.charge={};
				if("SUCCESS"==response.status){
					obj.result.charge=response.result.charge[0];
				}
				
				fn(obj);
			})
			.catch(function(){
				fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
			})
		}else{
			fn(responseObj("FAILURE",errorObj("EZECLI_323020","Device not initialized, call INITIALIZE API."),null))
		}
	}

	thi.searchCharges=function(searchChargeObj,fn){
		if(thi.initializationDone){
				
			ezecliWrapper.searchCharges(searchChargeObj)
			.then(function(response){
				//logger.info(response)
				if("SUCCESS"==response.status){
					fn(response);
				}else{
					fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
				}	
				
			})
			.catch(function(){
				fn(responseObj("FAILURE",errorObj("EZECLI_0001","Exception occured. Contact Ezetap Support!!!"),null));
			})
		}else{
			fn(responseObj("FAILURE",errorObj("EZECLI_323020","Device not initialized, call INITIALIZE API."),null))
		}
	}

	function constructTransactionObjectList(response){
		var data=new Array(response.txns.length)
		for(var i=0;i<data.length;i++){
			var txn=response.txns[i];
			var type="";
					if(txn.txnType==3){
						type="cash"
					}else if(txn.txnType==4){
						type="cheque"
					}else{
						type="card";
					}
					data[i]=constructSearchTransactionPayementObj(txn,type);
				}
				return {"data":data};
			}

			var responseObj=function(status,error,result){
				return {
					"status":status,
					"error":error,
					"result":result
				}
			}

			var errorObj=function(errorCode,errorText){
				return {"code":errorCode,"message":errorText};
			}

			var populateAdditionalParams=function(options){
				var additionalParams={};
				if(options==undefined) {
					return {}
				}
				if(options.customer!=null){
					additionalParams.customerMobile=options.customer.mobileNo;
					additionalParams.customerEmail=options.customer.email;
				}
				if(options.references!=null){
					additionalParams.orderId=options.references.primaryRef
					additionalParams.externalReference2=options.references.ref2;
					additionalParams.externalReference3=options.references.ref3;
				}
				if(options.amountCashback!=null){
					additionalParams.amountOther=parseFloat(options.amountCashback);
				}else{
					additionalParams.amountOther=0;
				}

				return additionalParams;
			}

			var constructPayementObj=function(obj,type,charge){
				try{
					var obj_temp={};
					//obj_temp.txn={};
					/*obj_temp.customer={};
					obj_temp.receipt={};*/

					var temp={};

					var txnMapper={
						"txnId":"txnId",
						"postingDate":"txnDate",
						"amount":"amount",
						"currencyCode":"currencyCode",
						"paymentMode":"paymentMode",
						"txnType":"txnType",
						"authCode":"authCode",
						"deviceSerial":"deviceSerial",
						"mid":"mid", 
						"tid":"tid",
						"settlementStatus":"status",
						"receiptUrl":"receiptURL",
						"signReqd":"signReqd"
					}
					/*var customerMapper={
						"customerEmail":"email",
						"customerMobile":"mobileNo"
					}	

					var receiptMapper={
						"customerReceiptUrl":"receiptUrl",
						"readableChargeSlipDate":"receiptDate"
					}

					var references={
						"externalRefNumber":"primaryRef",
						"externalRefNumber2":"ref2",
						"externalRefNumber3":"ref3"
					}*/
					
			for(var property in txnMapper){
				if(txnMapper.hasOwnProperty(property)){
					if(obj[property]!=null && obj[property]!=""){
						var str=property;
						if(property == 'postingDate'){
							var date = new Date(obj[property]);
							temp[txnMapper[property]]= date.toISOString().replace(/T/, ' ').replace(/\..+/, '');	
						}else{
							temp[txnMapper[property]]=obj[property];
						}
					}
				}
			}
			obj_temp.currentTxn=temp;

			temp={};
			/*temp={};

			for(var property in references){
				if(references.hasOwnProperty(property)){
					if(obj[property]!=null && obj[property]!=""){
						var str=property;
						temp[references[property]]=obj[property];
					}
				}
			}
			obj_temp.references=temp;
			temp={};

			for(var property in customerMapper){
				if(customerMapper.hasOwnProperty(property)){
					if(obj[property]!=null && obj[property]!=""){
						var str=property;
						temp[customerMapper[property]]=obj[property];
					}
				}
			}
			obj_temp.customer=temp;
			temp={};
			for(var property in receiptMapper){
				if(receiptMapper.hasOwnProperty(property)){
					if(obj[property]!=null && obj[property]!=""){
						var str=property;
						temp[receiptMapper[property]]=obj[property];
					}
				}
			}
			obj_temp.receipt=temp;
			temp={};
			*/
			if("card"===type){
				var cardMapper={
					"formattedPan":"maskedCardNo",
					"paymentCardBrand":"cardBrand",
					"authCode":"authCode",
					"deviceSerial":"deviceSerial",
					"mid":"mid",
					"tid":"tid"
				}
				for(var property in cardMapper){
					if(cardMapper.hasOwnProperty(property)){
						if(obj[property]!=null && obj[property]!=""){
							var str=property;
							temp[cardMapper[property]]=obj[property];
						}
					}
				}
				obj_temp.currentTxn.card=temp;
				temp={};

				var merchantMapper={
					"merchantCode":"merchantCode",
					"merchantName":"merchantName"
				}
				for(var property in merchantMapper){
					if(merchantMapper.hasOwnProperty(property)){
						if(obj[property]!=null && obj[property]!=""){
							var str=property;
							temp[merchantMapper[property]]=obj[property];
						}
					}
				}
				//obj_temp.merchant=temp;
			}
			temp={};
			if("cheque"===type){
				var chequeMapper={
					"chequeNumber":"chequeNumber",
					"bankCode":"bankCode",
					"chequeDate":"chequeDate"
				}
				for(var property in chequeMapper){
					if(chequeMapper.hasOwnProperty(property)){
						if(obj[property]!=null && obj[property]!=""){
							var str=property;
							temp[chequeMapper[property]]=obj[property];
						}
					}
				}
				obj_temp.cheque=temp;
			}

			temp={};
			obj_temp.charge=charge;
			return obj_temp;
		}catch(e){
			logger.info(e)
			return {};
		}
				
	}

	var constructSearchTransactionPayementObj=function(obj,type){
		var obj_temp={};
		obj_temp.txn={};
		obj_temp.customer={};
		obj_temp.receipt={};
		
		var temp={};

		var txnMapper={
			"transactionId":"txnId",
			"timestamp":"txnDate",
			"amount":"amount",
			"currencyCode":"currencyCode",
			"paymentMode":"paymentMode",
			"authCode":"authCode",
			"deviceSerial":"deviceSerial",
			"mid":"mid",
			"tid":"tid"
		}
		var customerMapper={
			"customerEmail":"email",
			"customerMobileNumber":"mobileNo"
		}	

		var receiptMapper={
			"receiptUrl":"receiptUrl",
			"readableChargeSlipDate":"receiptDate"
		}
		for(var property in txnMapper){
			if(txnMapper.hasOwnProperty(property)){
				if(obj[property]!=null){
					var str=property;
					temp[txnMapper[property]]=obj[property];
				}
			}
		}
		obj_temp.txn=temp;
		temp={};

		for(var property in customerMapper){
			if(customerMapper.hasOwnProperty(property)){
				if(obj[property]!=null){
					var str=property;
					temp[customerMapper[property]]=obj[property];
				}
			}
		}
		obj_temp.customer=temp;
		temp={};
		for(var property in receiptMapper){
			if(receiptMapper.hasOwnProperty(property)){
				if(obj[property]!=null){
					var str=property;
					temp[receiptMapper[property]]=obj[property];
				}
			}
		}
		obj_temp.receipt=temp;
		temp={};
		
		if("card"===type){
			var cardMapper={
				"maskedCardNumber":"maskedCardNo",
				"cardBrand":"cardBrand"
			}
			for(var property in cardMapper){
				if(cardMapper.hasOwnProperty(property)){
					if(obj[property]!=null){
						var str=property;
						temp[cardMapper[property]]=obj[property];
					}
				}
			}
			obj_temp.card=temp;
			temp={};

			var merchantMapper={
				"merchantCode":"merchantCode",
				"merchantName":"merchantName"
			}
			for(var property in merchantMapper){
				if(merchantMapper.hasOwnProperty(property)){
					if(obj[property]!=null){
						var str=property;
						temp[merchantMapper[property]]=obj[property];
					}
				}
			}
			obj_temp.merchant=temp;
		}
		temp={};
		if("cheque"===type){
			var chequeMapper={
				"chequeNumber":"chequeNumber",
				"bankCode":"bankCode",
				"chequeDate":"chequeDate"
			}
			for(var property in chequeMapper){
				if(chequeMapper.hasOwnProperty(property)){
					if(obj[property]!=null){
						var str=property;
						temp[chequeMapper[property]]=obj[property];
					}
				}
			}
			obj_temp.cheque=temp;
		}

		temp={};
		obj_temp.txn.paymentMode=type.toUpperCase();
		return obj_temp;
	}

	var isValid=function(data){
		if(data!== 'undefined' && data!=null && data!==""){
			return true
		}
		return false;
	}
}


module.exports = {
	EzetapRestImpl: function(ezecli)  {
		var instance=new EzetapRestImplTest(ezecli);
		return instance;
	}
}