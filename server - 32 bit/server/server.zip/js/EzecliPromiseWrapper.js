var Q=require('q');
var https = require('http');
var log=require('./logger');
var	logger = log.getLogger('ezeClient-appender');

function EzecliWrapper(eze){
	var that=this;
	/*if(ezetapRestImpl.chargeBaseUrl=="https://services.ezetap.com"){
		var https = require('http');
	}else{
		var https = require('http');
	}*/
	that.prepareDevice=function(){
		var deferred=Q.defer();
		try{
			logger.info('EzecliWrapper Enetring prepareDevice');
			eze.preparedevice(function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
						//ezetapRestImpl.prepareDevice="true";
						ezetapRestImpl.isPrepareDeviceDone=true;
						deferred.resolve(apio);
					}else{
						ezetapRestImpl.prepareDevice="false";

						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}		
					
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.abortCurrentTransaction=function(){
		var deferred=Q.defer();
		try{
			logger.info('EzecliWrapper Entering abortCurrent Txn');
			eze.abortCurrentTransaction(function(apio){
				try{
					console.log(apio.status);
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
						
						deferred.resolve(apio);
					}else{
						//ezetapRestImpl.prepareDevice="false";

						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}		
					
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}
	
	that.initialize=function(ezetapConfig){
		var deferred=Q.defer();
		logger.info('EzecliWrapper Enetring initialize');
		try{
			eze.setdriver(ezetapRestImpl.ezecliLocation);
			eze.start();
			if(ezetapConfig.appMode==="PROD"){
				ezetapRestImpl.appKey=ezetapConfig.prodAppKey;
				appMode=1;
			}else{
				ezetapRestImpl.appKey=ezetapConfig.demoAppKey;
				appMode=0;
			}
			that.setServerType(appMode)
			.then(function(){
				return that.login(ezetapConfig.username,ezetapRestImpl.appKey,1);
			})
			.then(function(){
				ezetapRestImpl.initializationDone=true;
				return that.prepareDevice();
			})
			.then(function(){
				deferred.resolve();
			})
			.catch(function(e){
				deferred.reject();
			})
		}catch(e){
			deferred.reject();
		}
		return deferred.promise;
	}

	that.login=function(username,password,loginmode){
		logger.info('EzecliWrapper Enetring login');
		var deferred=Q.defer();
		try{
			eze.login(username,password,loginmode,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
						deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
					
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.logout=function(){
		logger.info('EzecliWrapper Enetring logout');
		var deferred=Q.defer();
		try{
			
			if(ezetapRestImpl.initializationDone){
				logger.info('Going to logout as already initialized');
				eze.logout(function(apio){
					logger.info('Logout sucessful');
				try{
						if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
						deferred.resolve(apio);
						}else{
							deferred.reject(apio);
						}
					}catch(e){
						deferred.reject();
					}
				});
			}else{
				logger.info('Returning as initialization is not done');
				deferred.resolve();
			}
			
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.stop=function(){
		logger.info('EzecliWrapper Enetring stop');
		var deferred=Q.defer();
		try{
			eze.stop()
			deferred.resolve();
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.payCard=function(amount,options){
		logger.info('EzecliWrapper Enetring payCard');
		var deferred=Q.defer();
		try{
			eze.paycard(amount,options,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.payCardCash=function(amount,otherAmount,options){
		logger.info('EzecliWrapper Entering payCardCash');
		var deferred=Q.defer();
		try{
			eze.paycardCash(amount,otherAmount,options,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.payCash=function(amount,options){
		logger.info('EzecliWrapper Enetring payCash');
		var deferred=Q.defer();
		try{

			eze.paycash(amount,options,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.payCheque=function(amount,options){
		logger.info('EzecliWrapper Enetring payCheque');
		var deferred=Q.defer();
		try{

			eze.paycheque(amount,options,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.voidTransaction=function(txnId){
		logger.info('EzecliWrapper Enetring voidTxn');
		var deferred=Q.defer();
		try{

			eze.txnvoid(txnId,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		
		return deferred.promise;
	}

	that.sendReceipt=function(txnId,mobile,email){
		var deferred=Q.defer();
		try{
			
			eze.forwardreceipt(txnId,mobile,email,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.getTransaction=function(txnId){
		logger.info('EzecliWrapper Enetring getTxn');
		var deferred=Q.defer();
		try{
			
			eze.txndetail(txnId,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}	
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.searchTransaction=function(startDate,endDate){

		var deferred=Q.defer();
		try{
			
			eze.txnhistory(startDate,endDate,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
					deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.setServerType=function(serverType){
		logger.info('EzecliWrapper Enetring setServerType');
		var deferred=Q.defer();
		try{	
			eze.setServerType(serverType,function(apio){
				try{
					if(eze.model.ApiOutput.ResultStatus.SUCCESS == apio.status){
						deferred.resolve(apio);
					}else{
						deferred.reject(apio);
					}
				}catch(e){
					deferred.reject();
				}
			});
		}catch(e){
			deferred.reject();
		}
		
		return deferred.promise;
	}

	that.getDefaultErrorMessage = function(message){
		var response = {};
		response.result = null;
		response.status = "FAILURE";
		response.error = {};
		response.error.message = message;
		return response;
	}

	that.errorDefault = "Something went wrong. Please retry again";
	that.errorNetDown = "Connection failed. Check your Internet connection.";
	that.errorParsing = "Error occurred while parsing the response.";

	that.createCharge=function(charge,fn){
		logger.info('EzecliWrapper Enetring createcharge');
			var deferred=Q.defer();
		try{
			charge.accountId=ezetapRestImpl.accountId;
			var chargeJson=JSON.stringify(charge);
			//chargeJson.accountId=ezetapRestImpl.accountId;
			logger.info('charge'+chargeJson);
			
			var postheaders = {
			    'Content-Type' : 'application/json',
			    'key':ezetapRestImpl.appKey
			};
			var optionspost = {
			    host : ezetapRestImpl.chargeBaseUrl,
			    //port : 80,
			    path : '/charge_api/v1/charges/',
			    method : 'POST',
			    headers : postheaders
			};

			returnErrorObj = function(message){
				var error = {};
				error.message = message;
				return error;
			};

			

			var reqPost = https.request(optionspost, function(res) {
			 	var response="";
			 	res.setEncoding('utf8');
			    res.on('data', function(d) {
			    	response+=d;
			    });

			    res.on('end',function(e){
			    	try{
			    		response = JSON.parse(response);
			    		//logger.info('Chrge response=='+JSON.stringify(response.result));
						var resOut = {};
						if('status' in response === false)
							resOut.status = "FAILURE";
						else
							resOut.status = response.status;
						if('error' in response){
							if(typeof response.error === 'string'){
								resOut.error = returnErrorObj(response.error);
							}else if(typeof response.error === 'object'){
								resOut.error = response.error;
							}else{
								if("SUCCESS" != resOut.status){
									resOut.error = returnErrorObj(that.errorDefault);
								}else
									resOut.error = null;
							}
						}else{
							if("SUCCESS" != resOut.status){
								resOut.error = returnErrorObj(that.errorDefault);
							}else
								resOut.error = null;
						}
						if('result' in response == false)
							resOut.result = null;
						else{
							resOut.result = {};
							resOut.result = response.result;
						}
						//logger.info("Response=="+(JSON.stringify(resOut)));
						//logger.info(JSON.stringify(resOut));
						deferred.resolve(resOut);
						
						//fn(JSON.stringify(resOut));
			    	}catch(error){
			    		logger.info('In error block createcharge'+error);
			    		//logger.info(that.errorParsing+error);
			    		deferred.resolve(that.getDefaultErrorMessage(that.errorParsing));
			    		//fn(JSON.stringify(that.getDefaultErrorMessage(that.errorParsing)));
			    	}
				});
			});

		reqPost.write(chargeJson);
		reqPost.end();

		reqPost.on('error', function(error) {
			logger.info('In error block createcharge'+error);
			//logger.info(that.errorNetDown+error);
			//fn(JSON.stringify(that.getDefaultErrorMessage(that.errorNetDown)));			
		});
		
		
		}catch(e){
			logger.debug('error happened');
			logger.debug(e);
			//deferred.reject();
		}
		return deferred.promise;
	}

	that.addPayment=function(chargeId,amount,type,txnId){
		logger.info('inside add payemnt txnid'+txnId+' chargeid='+chargeId);
		var deferred=Q.defer();
		var addPayObj={};
		addPayObj.amount=amount;
		addPayObj.paymentType=type;
		addPayObj.txnId=txnId;
		addPayObj.userId=ezetapRestImpl.username;

		doPostCall(addPayObj,'/charge_api/v1/charges/'+chargeId+'/addPayment')
		.then(function(response){
			deferred.resolve(response);
		})
		.catch(function(){
			deferred.reject();
		})
		return deferred.promise;
	}

	that.createWalletTransaction=function(chargeId,walletProvider){
		logger.info('Enterring createWalletTxn chargeId='+chargeId+' wallet='+walletProvider);
		var deferred=Q.defer();
		var walletObj={};
		walletObj.chargeId=chargeId;
		walletObj.walletProvider=walletProvider;
		walletObj.username=ezetapRestImpl.username;
		doPostCall(walletObj,'/charge_api/v1/remotePay/walletTransaction')
		.then(function(response){
			deferred.resolve(response);
		})
		.catch(function(){
			deferred.reject();
		})
		return deferred.promise;
	}

	that.confirmWalletTransaction=function(txnId,walletOTP){
		logger.info('Enterring confirm walletTxn txnId='+txnId);
		var deferred=Q.defer();
		var walletObj={};
		walletObj.txnId=txnId;
		walletObj.walletOTP=walletOTP;
		doPostCall(walletObj,'/charge_api/v1/remotePay/confirmWalletTransaction')
		.then(function(response){
			deferred.resolve(response);
		})
		.catch(function(){
			deferred.reject();
		})
		return deferred.promise;
	}

	that.remoteTransaction=function(chargeId){
		logger.info('Enterring remotePay chargeId='+chargeId);
		var deferred=Q.defer();
		var remoteObj={};
		remoteObj.chargeId=chargeId;
		remoteObj.username=ezetapRestImpl.username;
		//walletObj.walletOTP=walletOTP;
		doPostCall(remoteObj,'/charge_api/v1/remotePay/initiate')
		.then(function(response){
			deferred.resolve(response);
		})
		.catch(function(){
			deferred.reject();
		})
		return deferred.promise;
	}

	that.updateCustomer=function(customerObj){
		logger.info('Enterring update customer chargeId='+customerObj.chargeId);
		var deferred=Q.defer();
		doPutCall(customerObj.customer,'/charge_api/v1/charges/editCustomer/'+customerObj.chargeId)
		.then(function(response){
			deferred.resolve(response);
		})
		.catch(function(){
			deferred.reject();
		})
		return deferred.promise;
	}

	that.viewCharge=function(chargeId){
		logger.info('Enterring view charge chargeId='+chargeId);
		var deferred=Q.defer();
		doGetCall('/charge_api/v1/charges/'+chargeId)
		.then(function(response){
			deferred.resolve(response);
		})
		.catch(function(){
			deferred.reject();
		})
		return deferred.promise;
	}

	that.searchCharges=function(searchChargeObj){
		logger.info('Enterring searchCharges');
		var deferred=Q.defer();

		doGetCall('/charge_api/v1/charges/search?accountId='+ezetapRestImpl.accountId+'&status='+searchChargeObj.status+'&startDate='+searchChargeObj.startDate+'+00:00:00'+'&endDate='+searchChargeObj.endDate+'+00:00:00')
		.then(function(response){
			deferred.resolve(response);
		})
		.catch(function(){
			deferred.reject();
		})
		return deferred.promise;
	}

	doPostCall=function(postObj,uri){
		//logger.info('Entering doPost call uri='+uri+ ' obj'+JSON.stringify(postObj))
		var deferred=Q.defer();
		try{
			var postJSON=JSON.stringify(postObj);
			var postheaders = {
			    'Content-Type' : 'application/json',
			    'key':ezetapRestImpl.appKey
			};
			var optionspost = {
			    host : ezetapRestImpl.chargeBaseUrl,
			    //port : 80,
			    path : uri,
			    method : 'POST',
			    headers : postheaders
			};

			returnErrorObj = function(message){
				var error = {};
				error.message = message;
				return error;
			};

			

			var reqPost = https.request(optionspost, function(res) {
				//logger.info('in reqPost')
			 	var response="";
			 	res.setEncoding('utf8');
			    res.on('data', function(d) {
			    	//logger.info(d);
			    	response+=d;
			    });

			    res.on('end',function(e){
			    	//logger.info('in en =d reponse')
			    	try{
			    		response = JSON.parse(response);
			    		//logger.info('Chrge response=='+JSON.stringify(response.result));
						var resOut = {};
						if('status' in response === false)
							resOut.status = "FAILURE";
						else
							resOut.status = response.status;
						if('error' in response){
							if(typeof response.error === 'string'){
								resOut.error = returnErrorObj(response.error);
							}else if(typeof response.error === 'object'){
								resOut.error = response.error;
							}else{
								if("SUCCESS" != resOut.status){
									resOut.error = returnErrorObj(that.errorDefault);
								}else
									resOut.error = null;
							}
						}else{
							if("SUCCESS" != resOut.status){
								resOut.error = returnErrorObj(that.errorDefault);
							}else
								resOut.error = null;
						}
						if('result' in response == false)
							resOut.result = null;
						else{
							resOut.result = {};
							resOut.result = response.result;
						}
						//logger.info("Response=="+(JSON.stringify(resOut)));
						//logger.info(resOut);
						deferred.resolve(resOut);
						
						//fn(JSON.stringify(resOut));
			    	}catch(error){
			    		logger.info(that.errorParsing+error);
			    		deferred.resolve(that.getDefaultErrorMessage(that.errorParsing));
			    		//fn(JSON.stringify(that.getDefaultErrorMessage(that.errorParsing)));
			    	}
				});
			});

		reqPost.write(postJSON);
		reqPost.end();

		reqPost.on('error', function(error) {
			logger.info(that.errorNetDown+error);
			//fn(JSON.stringify(that.getDefaultErrorMessage(that.errorNetDown)));			
		});
		
		
		}catch(e){
			logger.debug('error happened');
			logger.debug(e);
			//deferred.reject();
		}
		return deferred.promise;
	}

	doPutCall=function(postObj,uri){
		console.log("uri=="+uri)
		//logger.info('Entering doPost call uri='+uri+ ' obj'+JSON.stringify(postObj))
		var deferred=Q.defer();
		try{
			var postJSON=JSON.stringify(postObj);
			var postheaders = {
			    'Content-Type' : 'application/json',
			    'key':ezetapRestImpl.appKey
			};
			var optionspost = {
			    host : ezetapRestImpl.chargeBaseUrl,
			    //port : 80,
			    path : uri,
			    method : 'PUT',
			    headers : postheaders
			};

			returnErrorObj = function(message){
				var error = {};
				error.message = message;
				return error;
			};

			

			var reqPost = https.request(optionspost, function(res) {
				//logger.info('in reqPost')
			 	var response="";
			 	res.setEncoding('utf8');
			    res.on('data', function(d) {
			    	//logger.info(d);
			    	response+=d;
			    });

			    res.on('end',function(e){
			    	//logger.info('in en =d reponse')
			    	try{
			    		response = JSON.parse(response);
			    		//logger.info('Chrge response=='+JSON.stringify(response.result));
						var resOut = {};
						if('status' in response === false)
							resOut.status = "FAILURE";
						else
							resOut.status = response.status;
						if('error' in response){
							if(typeof response.error === 'string'){
								resOut.error = returnErrorObj(response.error);
							}else if(typeof response.error === 'object'){
								resOut.error = response.error;
							}else{
								if("SUCCESS" != resOut.status){
									resOut.error = returnErrorObj(that.errorDefault);
								}else
									resOut.error = null;
							}
						}else{
							if("SUCCESS" != resOut.status){
								resOut.error = returnErrorObj(that.errorDefault);
							}else
								resOut.error = null;
						}
						if('result' in response == false)
							resOut.result = null;
						else{
							resOut.result = {};
							resOut.result = response.result;
						}
						//logger.info("Response=="+(JSON.stringify(resOut)));
						//logger.info(resOut);
						deferred.resolve(resOut);
						
						//fn(JSON.stringify(resOut));
			    	}catch(error){
			    		logger.info(that.errorParsing+error);
			    		deferred.resolve(that.getDefaultErrorMessage(that.errorParsing));
			    		//fn(JSON.stringify(that.getDefaultErrorMessage(that.errorParsing)));
			    	}
				});
			});

		reqPost.write(postJSON);
		reqPost.end();

		reqPost.on('error', function(error) {
			logger.info(that.errorNetDown+error);
			//fn(JSON.stringify(that.getDefaultErrorMessage(that.errorNetDown)));			
		});
		
		
		}catch(e){
			logger.debug('error happened');
			logger.debug(e);
			//deferred.reject();
		}
		return deferred.promise;
	}

	doGetCall=function(uri){
		//console.log("uri=="+uri)
		//logger.info('Entering doPost call uri='+uri+ ' obj'+JSON.stringify(postObj))
		var deferred=Q.defer();
		try{
			//var postJSON=JSON.stringify(postObj);
			var postheaders = {
			    'Content-Type' : 'application/json',
			    'key':ezetapRestImpl.appKey
			};
			var optionspost = {
			    host : ezetapRestImpl.chargeBaseUrl,
			    //port : 80,
			    path : uri,
			    method : 'GET',
			    headers : postheaders
			};

			returnErrorObj = function(message){
				var error = {};
				error.message = message;
				return error;
			};

			

			var reqPost = https.request(optionspost, function(res) {
				//logger.info('in reqPost')
			 	var response="";
			 	res.setEncoding('utf8');
			    res.on('data', function(d) {
			    	//logger.info(d);
			    	response+=d;
			    	//console.log('Getting data '+d)
			    });

			    res.on('end',function(e){
			    	//console.log('in end resonse');
			    	//logger.info('in en =d reponse')
			    	try{
			    		response = JSON.parse(response);
			    		//logger.info('Chrge response=='+JSON.stringify(response.result));
						var resOut = {};
						if('status' in response === false)
							resOut.status = "FAILURE";
						else
							resOut.status = response.status;
						if('error' in response){
							if(typeof response.error === 'string'){
								resOut.error = returnErrorObj(response.error);
							}else if(typeof response.error === 'object'){
								resOut.error = response.error;
							}else{
								if("SUCCESS" != resOut.status){
									resOut.error = returnErrorObj(that.errorDefault);
								}else
									resOut.error = null;
							}
						}else{
							if("SUCCESS" != resOut.status){
								resOut.error = returnErrorObj(that.errorDefault);
							}else
								resOut.error = null;
						}
						if('result' in response == false)
							resOut.result = null;
						else{
							resOut.result = {};
							resOut.result = response.result;
						}
						//logger.info("Response=="+(JSON.stringify(resOut)));
						//logger.info('reponse='+JSON.stringify(resOut));
						deferred.resolve(resOut);
						
						//fn(JSON.stringify(resOut));
			    	}catch(error){
			    		//console.log(error)
			    		logger.info('error='+that.errorParsing+error);
			    		deferred.resolve(that.getDefaultErrorMessage(that.errorParsing));
			    		//fn(JSON.stringify(that.getDefaultErrorMessage(that.errorParsing)));
			    	}
				});
			});

		//reqPost.write(postJSON);
		reqPost.end();

		reqPost.on('error', function(error) {
			logger.info(that.errorNetDown+error);
			//fn(JSON.stringify(that.getDefaultErrorMessage(that.errorNetDown)));			
		});
		
		
		}catch(e){
			logger.debug('error happened');
			logger.debug(e);
			//console.log(e)
			//deferred.reject();
		}
		return deferred.promise;
	}
}

module.exports = {
    EzecliWrapper: function(ezecli)  {
		var instance=new EzecliWrapper(ezecli);
		return instance;
    }
  }